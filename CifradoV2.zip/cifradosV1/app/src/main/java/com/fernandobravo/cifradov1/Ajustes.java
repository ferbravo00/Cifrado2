package com.fernandobravo.cifradov1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

import com.fernandobravo.cifradov1.MainActivity;

public class Ajustes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);

        final Button radio1 = findViewById(R.id.radioButton);
        final Button radio2 = findViewById(R.id.radioButton2);
        final Button radio3 = findViewById(R.id.radioButton3);
        final Switch sw1 = findViewById(R.id.switch1);


        sw1.setChecked(MainActivity.gESTADO);

        if(MainActivity.gESTADO){
            MainActivity.textESTADO.setText("Cifrar al escribir");
            sw1.setChecked(true);
        }else{
            MainActivity.textESTADO.setText("");
            sw1.setChecked(false);
        }


        sw1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sw1.isChecked()) {
                    MainActivity.gESTADO = true;
                    MainActivity.textESTADO.setText("Cifrar al escribir");
                } else {
                    MainActivity.gESTADO = false;
                    MainActivity.textESTADO.setText("");
                }
            }
        });

    }


}